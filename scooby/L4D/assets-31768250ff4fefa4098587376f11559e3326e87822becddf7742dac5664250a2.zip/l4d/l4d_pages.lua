-- Product pages use the template's native groups, feature rows, binds and color pickers.
ui.feature_visible("demo.animate", false)
-- Built-in feature pages share a three-column layout; file browsers and user Lua keep their own layouts.
local function protectedGroup(label,id,draw)
    ui.group(label,function() l4d.protected_control(id,draw) end)
end
local function columns(draw)
    ui.columns(3,draw,true)
end
local function choice(label,id,field,items,materialChoice)
    l4d.protected_control(id,function()
    imgui.text(label:gsub("##.*", ""))
    local changed,value=ui.combo("##"..label,l4d.setting(id,field)+1,items)
    if changed then l4d.setting(id,field,value-1);if materialChoice then l4d.user_material(id,0) end end
    end)
end
local function slider(label,id,field,low,high)
    l4d.protected_control(id,function()
    local changed,value=ui.slider(label,l4d.setting(id,field),low,high)
    if changed then l4d.setting(id,field,value) end
    end)
end
local infectedTypes={"Common infected","Uncommon infected","Witch","Smoker","Boomer","Hunter","Spitter","Jockey","Charger","Tank","Unknown special"}
local infectedIds={"common","uncommon","witch","smoker","boomer","hunter","spitter","jockey","charger","tank","unknown"}
local function toggle(label,id)
    l4d.protected_control(id,function()
        local changed,value=ui.toggle(label,features.get(id))
        if changed then features.set(id,value) end
    end)
end
local espTargets={"Players","Zombies","Special zombies"}
local espPrefixes={"esp.","esp.zombies.","esp.specials."}
local lastZombieType,lastSpecialType=1,3
local lastEspTarget
local function actorBoxes()
    ui.group("Actor boxes",function()
        ui.feature("actor.fit")
        if features.get("actor.fit") then
            slider("Padding (%)","actor.box_padding","distance",0,10)
        else
            slider("Width (%)","actor.box_width","distance",25,100)
            slider("Height (%)","actor.box_height","distance",50,100)
        end
        if ui.button("Reset box fit") then
            features.set("actor.fit",true)
            l4d.setting("actor.box_padding","distance",1.5)
        end
    end)
end
local function playersPage(target)
    l4d.setting("esp.target","style",target-1)
    local selected
    if target>1 then
        local first,last=target==2 and 1 or 3,target==2 and 2 or #infectedTypes
        selected=lastEspTarget and lastEspTarget~=target and
            (target==2 and lastZombieType or lastSpecialType) or l4d.setting("infected.selector","style")+1
        selected=math.max(first,math.min(last,selected))
        l4d.setting("infected.selector","style",selected-1)
    end
    lastEspTarget=target
    ui.columns(2,function()
        local prefix=espPrefixes[target]
        ui.group(espTargets[target].." ESP",function()
            ui.feature(prefix.."enabled")
            if target==1 then toggle("Survivors","l4d.survivors") end
            slider("Range (m)",prefix.."enabled","distance",1,1000)
            for _,part in ipairs({"box","skeleton","name","health","distance","snaplines"}) do
                if selected and part~="health" then
                    l4d.esp_feature(prefix..part,"infected."..infectedIds[selected].."."..part)
                else ui.feature(prefix..part) end
            end
            if target==1 then
                l4d.player_extra_feature("esp.line_of_sight")
                l4d.player_extra_feature("esp.weapon")
            end
            ui.feature(prefix.."hat")
            ui.feature(prefix.."ring")
            ui.feature(prefix.."head")
            ui.feature(prefix.."trail")
            l4d.esp_extra(prefix.."status")
            l4d.esp_extra(prefix.."arrows")
            if target==3 then l4d.esp_extra("esp.witch_anger") end
        end)
        if target==1 then
            actorBoxes()
            ui.group("Player overrides",function() l4d.player_esp_rules() end)
        else
            local first,last=target==2 and 1 or 3,target==2 and 2 or #infectedTypes
            local types={}
            for i=first,last do types[#types+1]=infectedTypes[i] end
            ui.group("Type filters",function()
                toggle("All zombies","l4d.infected")
                if target==3 then toggle("Special infected","infected.specials") end
                local changed,value=ui.combo("##espInfectedType",selected-first+1,types)
                if changed then selected=value+first-1;l4d.setting("infected.selector","style",selected-1) end
                if target==2 then lastZombieType=selected else lastSpecialType=selected end
                local id="infected."..infectedIds[selected]
                toggle("Show this type",id)
                slider("Maximum range (m)",id,"distance",1,1000)
            end)
        end
        ui.next_column()
        l4d.model_preview(target==1 and "players" or "infected")
    end,false,true)
end
ui.subtab("visuals","zombies","Zombies",function() playersPage(2) end,{hidden=true})
ui.subtab("visuals","special_zombies","Special zombies",function() playersPage(3) end,{hidden=true})
-- Preserve legacy script routes; visible controls are grouped under Visuals > ESP.
ui.subtab("visuals","entities","Entities",function() playersPage(1) end,{hidden=true})
ui.subtab("visuals","infected","Infected",function()
    playersPage(l4d.setting("infected.selector","style")<2 and 2 or 3)
end,{hidden=true})
local materials={"Lit","Flat","Chrome","Ghost","Additive","Wireframe","Glass","Glow","Fullbright","Chrome wireframe","Ghost wireframe","Neon wireframe","Galaxy","Galaxy flow","Lightning","Lightning overlay","Plasma flow","Aurora","Molten","Dark Matter","Acid","Vortex","Hologram","Frost","Inferno","Circuit","Pearl"}
local function supportsAnimation(style) return style>=12 and style<#materials end
-- Keep persisted selector indices and remember each group's last target.
local chamsGroups={
    {labels={"Players"},targets={1}},
    {labels={"Common infected","Uncommon infected"},targets={7,8}},
    {labels={"Witch","Smoker","Boomer","Hunter","Spitter","Jockey","Charger","Tank","Unknown special"},targets={9,10,11,12,13,14,15,16,17}},
    {labels={"Dropped weapons","Items"},targets={4,5}},
    {labels={"Self","Arms","Weapon","Held weapon (world)"},targets={6,2,3,18}},
}
local chamsLastTargets={1,7,9,4,6}
local chamsMasters={"chams.players.enabled","chams.zombies.enabled","chams.specials.enabled","chams.pickups.enabled","chams.self.enabled"}
local chamsLife={"chams.players.","chams.zombies.","chams.specials.",nil,"chams.self."}
local function chamsMaster(selected)
    for group,entry in ipairs(chamsGroups) do
        for _,target in ipairs(entry.targets) do if target==selected then return chamsMasters[group] end end
    end
    return chamsMasters[1]
end
ui.feature_visible("chams.legacy_master",false)
ui.feature_visible("chams.legacy_range",false)
local function chamsTargetTabs()
    local selected=l4d.setting("chams.selector","style")+1
    local group=1
    for i,entry in ipairs(chamsGroups) do
        for _,target in ipairs(entry.targets) do
            if selected==target then group=i;chamsLastTargets[i]=selected end
        end
    end
    local nextGroup=l4d.target_tabs("chams",group)
    if nextGroup~=group then
        selected=chamsLastTargets[nextGroup]
        l4d.setting("chams.selector","style",selected-1)
    end
    return nextGroup
end
-- The VFX material inspector retains its compact all-target picker.
local chamsTypes={"Players","Self","Common infected","Uncommon infected","Special infected","Witch","Arms","Weapon","Held weapon (world)","Dropped weapons","Items"}
-- Map the grouped menu to the existing saved selector; existing configs and Lua indices remain stable.
local chamsTypeTargets={1,6,7,8,10,9,2,3,18,4,5}
local specialChamsTypes={"Smoker","Boomer","Hunter","Spitter","Jockey","Charger","Tank","Unknown special"}
local lastSpecialChams=10
local function chamsAllTargetsDropdown()
    local selected=l4d.setting("chams.selector","style")+1
    local category=1
    if selected>=10 and selected<=17 then
        category=5
        lastSpecialChams=selected
    else
        for i,target in ipairs(chamsTypeTargets) do
            if selected==target then category=i;break end
        end
    end
    imgui.text("Target")
    local changed,value=ui.combo("##chamsType",category,chamsTypes)
    if changed then
        category=value
        selected=category==5 and lastSpecialChams or chamsTypeTargets[category]
        l4d.setting("chams.selector","style",selected-1)
    end
    if category==5 then
        imgui.text("Infected type")
        changed,value=ui.combo("##chamsInfectedType",selected-9,specialChamsTypes)
        if changed then
            selected=value+9
            lastSpecialChams=selected
            l4d.setting("chams.selector","style",selected-1)
        end
    end
    return selected
end
local function chamsTargetDropdown(group)
    if not group then return chamsAllTargetsDropdown() end
    local entry=chamsGroups[group]
    local selected=l4d.setting("chams.selector","style")+1
    if #entry.targets>1 then
        local index=1
        for i,target in ipairs(entry.targets) do if target==selected then index=i end end
        imgui.text("Target")
        local changed,value=ui.combo("##chamsType",index,entry.labels)
        if changed then
            selected=entry.targets[value]
            chamsLastTargets[group]=selected
            l4d.setting("chams.selector","style",selected-1)
        end
    end
    return selected
end
local chamsIds={"chams.survivors","chams.arms","chams.held","chams.weapons","chams.pickups","chams.self","chams.common","chams.uncommon","chams.witch","chams.smoker","chams.boomer","chams.hunter","chams.spitter","chams.jockey","chams.charger","chams.tank","chams.unknown","chams.world_weapon"}
local chamsTargetNames={"Players","Arms","Weapon","Dropped weapons","Items","Self","Common infected","Uncommon infected","Witch","Smoker","Boomer","Hunter","Spitter","Jockey","Charger","Tank","Unknown special","Held weapon (world)"}
local animationLayer=1
ui.subtab("visuals", "chams", "Chams", function()
    local group=chamsTargetTabs()
    ui.columns(2,function()
        protectedGroup("Chams","chams.enabled",function()
            toggle("Enable",chamsMasters[group])
            local selected=chamsTargetDropdown(group)
            toggle("Enable target",chamsIds[selected])
            if selected>=10 and selected<=17 then toggle("Special infected","chams.special") end
            if selected~=2 and selected~=3 then slider("Range (m)",chamsMasters[group],"distance",1,300) end
            if chamsLife[group] then
                toggle("Show dead",chamsLife[group].."dead");toggle("Show ragdolls",chamsLife[group].."ragdolls")
            end
        end)
        local selected=l4d.setting("chams.selector","style")+1
        local id=chamsIds[selected]
        local visible=selected==1 and "chams.visible" or id..".custom"
        local invisible=selected==1 and "chams.hidden" or id..".hidden"
        local overlay=id..".overlay"
        local animationSupported=supportsAnimation(l4d.setting(visible,"style")) or supportsAnimation(l4d.setting(invisible,"style")) or
            (features.get(overlay) and supportsAnimation(l4d.setting(overlay,"style")))
        protectedGroup(chamsTargetNames[selected],"chams.enabled",function()
            ui.feature(visible)
            choice("Visible material",visible,"style",materials,true)
            ui.feature(invisible)
            choice("Invisible material",invisible,"style",materials,true)
            imgui.spacing(6)
            local changed,value=ui.combo("Layer",animationLayer,{"Visible","Invisible","Overlay"})
            if changed then animationLayer=value end
            local pass=({visible,invisible,overlay})[animationLayer]
            local animation=pass..".animation"
            local mode=l4d.setting(animation,"style")
            if mode==1 or mode==6 or mode==7 then ui.feature(animation) else toggle("Custom animation",animation) end
            if features.get(animation) then
                choice("Mode",animation,"style",{"Static","Color wave","Pulse opacity","Rainbow colors","Shimmer","Ember flicker","Color surge","Color steps"})
                if mode~=0 then
                    slider("Speed (Hz)",animation.."_speed","distance",0.05,3)
                    slider("Strength",animation.."_amount","distance",0,1)
                end
                ui.keybind(animation)
            end
        end)
        protectedGroup("Overlay","chams.enabled",function()
            ui.feature(overlay)
            if features.get(overlay) then choice("Overlay material",overlay,"style",materials,true) end
        end)
        protectedGroup("Shared effects","chams.enabled",function()
            ui.feature("chams.overlay");ui.feature("chams.wire")
            ui.feature("chams.pulse");ui.feature("chams.rainbow")
            if animationSupported then
                ui.feature("chams.animation")
                if features.get("chams.animation") then
                    choice("Mode","chams.animation","style",{"Color wave","Breathing","Shimmer"})
                    slider("Speed (Hz)","chams.animation_speed","distance",0.05,3)
                    slider("Strength","chams.animation_amount","distance",0,1)
                end
            end
            slider("Pulse speed (Hz)","chams.pulse","thickness",0.5,5)
            ui.feature("chams.copy_pass");ui.feature("chams.swap_passes")
        end)

        ui.next_column()
        l4d.model_preview("chams")
    end,false,true)
end)
local function pickupsPage()
    ui.columns(2,function()
        ui.group("Weapons and items",function()
            l4d.esp_extra("projectiles.enabled")
            ui.feature("l4d.items")
            ui.feature("items.weapons");ui.feature("items.melee");ui.feature("items.throwables")
            ui.feature("items.medical");ui.feature("items.ammo");ui.feature("items.upgrades");ui.feature("items.carryables")
        end)
        ui.group("Appearance",function()
            ui.feature("items.box")
            choice("Box style","items.box","style",{"Rectangle","Corners"})
            ui.feature("items.name");ui.feature("items.distance");ui.feature("items.snaplines")
            ui.feature("items.weapon_icon")
            slider("Range (m)","l4d.items","distance",1,1000)
            slider("Label size","l4d.items","textSize",10,24)
        end)
        ui.next_column()
        l4d.model_preview("pickups")
    end,false,true)
end
ui.subtab("visuals","pickups","Pickups",pickupsPage,{hidden=true})
local espTab=1
ui.override("visuals/esp",function()
    espTab=l4d.target_tabs("esp",espTab)
    if espTab==4 then pickupsPage() else playersPage(espTab) end
end)
local function activationKey(label,id,compact)
    if label then imgui.text(label);imgui.same_line(8) end
    local key,mode,capturing,waiting=l4d.keybind(id)
    local caption=waiting and "Wait 0.5s..." or capturing and "Press a key..." or "Set key"
    local width=imgui.available()
    local buttonLabel=key~="" and not capturing and not waiting and key or ui.tr(caption)
    if ui.button(buttonLabel.."###set_"..id,math.min(160,width*.45)) then l4d.keybind(id,"capture") end
    if key~="" then
        if width>=240 then imgui.same_line(6) end
        if ui.button(ui.tr("Clear bind").."###clear_"..id) then l4d.keybind(id,"clear") end
    end
    if compact and width>=(key=="" and 230 or 360) then imgui.same_line(6) end
    local changed,value=ui.combo("##"..id.."mode",mode+1,{"Always","Toggle","Hold","Hold to disable"})
    if changed then l4d.keybind(id,"mode",value-1) end
end
local function keyedFeature(id)
    ui.feature(id)
    l4d.protected_control(id,function() activationKey("Key",id,true) end)
end
local targetLabels={"Common infected","Special infected","Witch","Survivors"}
local targetIds={"common","special","witch","survivors"}
local function targets(prefix)
    local selected={}
    for i,id in ipairs(targetIds) do selected[i]=features.get(prefix..id) end
    local changed,values=ui.multi_combo("##"..prefix.."targets",selected,targetLabels)
    if changed then
        for i,id in ipairs(targetIds) do
            if values[i]~=selected[i] then features.set(prefix..id,values[i]) end
        end
    end
end
local hitboxes={"Upper body","Chest","Head","Stomach","Arms","Legs","All"}
-- Persisted value 6 already scans every hitbox and ranks by crosshair angle.
local aimHitboxes={"Upper body","Chest","Head","Stomach","Arms","Legs","Nearest"}
local function aimPage(title,rage)
    if rage==nil then rage=l4d.setting("aim.profile","style")==1;title=rage and "Rage" or "Legit" end
    local aim=rage and "aim.rage." or "aim."
    local weapon=rage and "weapon.rage." or "weapon."
    l4d._aim_page(function()
    columns(function()
        ui.group(title.." aiming",function()
            ui.feature(aim.."enabled")
            activationKey("Aim key",aim.."key")
            choice("Aim mode",aim.."mode","style",{"Camera","Silent","pSilent"})
            ui.feature(aim.."autofire")
            ui.feature(aim.."lock");ui.feature(aim.."attack");ui.feature(aim.."visible")
        end)
        ui.next_column()
        ui.group("Targets",function()
            targets(aim)
            slider("Maximum range (m)",aim.."range","distance",1,300)
            choice("Target priority",aim.."priority","style",{"Crosshair","Special infected","Survivors","Common infected"})
            choice("Hitboxes",aim.."point","style",aimHitboxes)
        end)
        ui.group("Weapon controls",function()
            ui.feature(weapon.."no_recoil")
        end)
        ui.next_column()
        ui.group("Aim visuals",function()
            local prefix=rage and "aim.rage." or "aim.legit."
            ui.feature(prefix.."circle");ui.feature(prefix.."snapline");ui.feature(prefix.."dot")
        end)
        ui.group("Response",function()
            slider("Field of view (degrees)",rage and "aim.rage" or "aim.legit","distance",1,180)
            if not rage and l4d.setting(aim.."mode","style")==0 then slider("Smoothing",aim.."smoothing","distance",1,30) end
        end)
    end)
    end)
end
local aimbot=ui.tab("aimbot","Aimbot",{section="Combat",icon=0xe180})
ui.subtab(aimbot,"aimbot_aim","Aim",function() aimPage() end)
local rage=ui.tab("rage","Rage",{hidden=true})
ui.subtab(rage,"rage_aim","Ragebot",function() aimPage("Rage",true) end)
local legit=ui.tab("legit","Legit",{hidden=true})
ui.subtab(legit,"legit_aim","Legitbot",function() aimPage("Legit",false) end)
local function triggerPage(title,rage)
    if rage==nil then rage=l4d.setting("aim.profile","style")==1;title=rage and "Rage" or "Legit" end
    local trigger=rage and "trigger.rage." or "trigger."
    local weapon=rage and "weapon.rage." or "weapon."
    columns(function()
        ui.group("Triggerbot",function()
            ui.feature(trigger.."enabled")
            activationKey("Trigger key",trigger.."key")
            slider("Reaction delay (ms)",trigger.."delay","distance",0,500)
            slider("Maximum range (m)",trigger.."range","distance",1,300)
        end)
        ui.next_column()
        ui.group("Targets",function()
            targets(trigger)
            choice("Hitboxes",trigger.."hitbox","style",hitboxes)
        end)
        ui.next_column()
        ui.group("Weapon controls",function()
            ui.feature(weapon.."no_recoil")
        end)
    end)
end
ui.subtab(aimbot,"aimbot_trigger","Triggerbot",function() triggerPage() end)
ui.subtab(rage,"rage_triggerbot","Triggerbot",function() triggerPage("Rage",true) end)
ui.subtab(legit,"triggerbot","Triggerbot",function() triggerPage("Legit",false) end)
local function antiAimPage()
    columns(function()
        ui.group("Anti-Aim",function()
            ui.feature("antiaim.enabled")
            activationKey("AntiAim Hotkey","antiaim.key")
            ui.feature("antiaim.invert")
        end)
        ui.next_column()
        ui.group("Yaw",function()
            choice("Yaw","antiaim.yaw","style",{"Backwards","Left","Right","Jitter","Spin","Random","Distortion","Switch","View"})
            slider("Yaw Offset","antiaim.yaw_offset","distance",-180,180)
            local yaw=l4d.setting("antiaim.yaw","style")
            if yaw==4 then slider("Spin Speed","antiaim.spin","distance",30,1440) end
            if yaw==3 or yaw==6 then slider("Jitter Range","antiaim.jitter","distance",0,180) end
        end)
        ui.next_column()
        ui.group("Pitch",function()
            choice("Pitch","antiaim.pitch","style",{"View","Down","Up","Zero","Jitter","Custom"})
            if l4d.setting("antiaim.pitch","style")==5 then
                slider("Custom Pitch","antiaim.custom_pitch","distance",-89,89)
            end
        end)
    end)
end
ui.subtab(aimbot,"aimbot_anti_aim","Anti-Aim",antiAimPage)
ui.subtab(rage,"anti_aim","Anti-Aim",antiAimPage)
local function hostPage(draw)
    local status=l4d.host_status()
    if not status.ready then imgui.text_wrapped(ui.tr(status.reason)) end
    l4d._local_controls(draw)
    if status.message~="" then imgui.text_wrapped(ui.tr(status.message)) end
end
local misc=ui.tab("misc","Misc",{section="Misc",icon=0xe3b9})
local spawnSelection={}
local spawnNotice=""
local function localPage()
    hostPage(function()
        ui.columns(2,function()
            ui.group("Spawn catalog",function()
                choice("Category","spawn.category","style",{"Weapons","Items","Ammo","Zombies"})
                local category=l4d.setting("spawn.category","style")+1
                local entries={}
                for _,entry in ipairs(l4d.spawn_catalog()) do
                    if entry.category==category then entries[#entries+1]=entry end
                end
                local selected=spawnSelection[category]
                local valid=false
                for _,entry in ipairs(entries) do if entry.id==selected then valid=true end end
                if not valid then selected=entries[1] and entries[1].id;spawnSelection[category]=selected end
                local _,availableHeight=imgui.available()
                local listHeight=math.max(90,math.min(260,availableHeight-60))
                imgui.child("spawn-list",0,listHeight,function()
                    for _,entry in ipairs(entries) do
                        l4d.protected_control("spawn.category",function()
                        if ui.selectable(ui.tr(entry.name).."##spawn_"..entry.id,entry.id==selected) then
                            selected=entry.id;spawnSelection[category]=selected
                        end
                        end)
                    end
                end)
                l4d.protected_control("spawn.category",function()
                if ui.button("Spawn selected") and selected then
                    local ok=l4d.spawn(selected,{
                        distance=l4d.setting("spawn.distance","distance"),
                        count=math.floor(l4d.setting("spawn.count","distance")),
                        dead=category==4 and features.get("spawn.dead"),
                        random=features.get("spawn.random")})
                    spawnNotice=ok and "" or "Spawn request unavailable or queue full."
                end
                end)
                if spawnNotice~="" then imgui.text_wrapped(ui.tr(spawnNotice)) end
            end)
            ui.next_column()
            ui.group("Spawn settings",function()
                slider("Spawn distance (units)","spawn.distance","distance",64,1500)
                l4d.protected_control("spawn.count",function()
                local changed,count=ui.slider_int("Spawn count",math.floor(l4d.setting("spawn.count","distance")),1,10)
                if changed then l4d.setting("spawn.count","distance",count) end
                end)
                ui.feature("spawn.random")
                if l4d.setting("spawn.category","style")==3 then ui.feature("spawn.dead") end
            end)
            ui.group("Player",function()
                ui.feature("self.god")
                l4d.protected_control("self.god",function()
                    if ui.button("Restore health") then l4d.self_action("heal") end
                end)
            end)
            ui.group("Ammunition",function()
                ui.feature("self.infinite_ammo");ui.feature("self.no_reload")
                l4d.protected_control("self.infinite_ammo",function()
                    if ui.button("Refill ammo") then l4d.self_action("refill") end
                end)
                imgui.text_wrapped(ui.tr("Godmode and No reload affect all players on your hosted server."))
            end)
            ui.group("Game",function()
                ui.feature("exploits.anti_fall");ui.feature("exploits.anti_afk")
                keyedFeature("exploits.airstuck");keyedFeature("exploits.save_position");keyedFeature("exploits.teleport")
                imgui.text_wrapped(ui.tr("Save a grounded position, then use Teleport."))
                ui.feature("exploits.anti_smoker")
                if l4d.info().game_id=="l4d2" then ui.feature("exploits.anti_jockey") end
                ui.feature("weapon.no_spread");ui.feature("weapon.rage.no_spread")
            end)
            ui.group("Player information",function()
                ui.feature("self.info")
                local player=l4d.local_player()
                if features.get("self.info") and player then
                    imgui.text(string.format(ui.tr("Health: %d"),player.health))
                    imgui.text(string.format(ui.tr("Speed: %.0f units/s"),player.speed))
                    imgui.text(string.format("X %.0f   Y %.0f   Z %.0f",player.position.x,player.position.y,player.position.z))
                    if player.weapon then
                        imgui.text(player.weapon.class_name)
                        if player.weapon.clip then imgui.text(string.format(ui.tr("Magazine: %d"),player.weapon.clip)) end
                    end
                end
            end)
        end)
    end)
end
ui.subtab(misc,"local","Local",localPage)
-- Preserve existing script/config routes without duplicate navigation entries.
ui.subtab(misc,"spawn_catalog","Spawner (Local / Host)",localPage,{hidden=true})
ui.subtab(misc,"self_player","Self (Local / Host)",localPage,{hidden=true})

ui.subtab(misc,"assistance","Movement",function()
    columns(function()
        ui.group("Movement",function() ui.feature("movement.bhop");ui.feature("movement.strafe") end)
        ui.next_column()
        ui.group("Telemetry",function()
            ui.feature("debug.telemetry")
            local speed= l4d.metrics()
            imgui.text(string.format(ui.tr("Speed: %.0f units/s"),speed))
            imgui.text("Hold jump for assistance. Ladders and deep water are excluded.")
        end)
    end)
end)
ui.subtab(misc,"exploits","Exploits",function()
    ui.columns(2,function()
        ui.group("Speed hack",function()
            keyedFeature("exploits.speed")
            slider("Extra movement ticks","exploits.speed_factor","distance",1,32)
        end)
        ui.group("Game",function()
            ui.feature("exploits.ping")
            imgui.text_wrapped(ui.tr("Reduces interpolation delay, not network latency."))
            ui.feature("exploits.no_push")
            ui.feature("exploits.pure")
        end)
        ui.next_column()
        ui.group("Lag exploit",function()
            keyedFeature("exploits.lag")
            slider("Sequence increment","exploits.lag_factor","distance",1,999)
        end)
    end,false,true)
end)
ui.subtab("visuals","hud","HUD",function()
    columns(function()
        ui.group("Team health HUD",function()
            ui.feature("hud.team");ui.feature("hud.incap")
            slider("Horizontal position (%)","hud.x","distance",0,100)
            slider("Vertical position (%)","hud.y","distance",0,100)
            slider("HUD width","hud.width","distance",180,480)
        end)
        ui.next_column()
        ui.group("Removals",function() ui.feature("visual.no_vomit") end)
    end)
end)
ui.subtab("visuals","glow","Glow",function()
    columns(function()
        ui.group("Native glow (L4D2)",function()
            ui.feature("glow.enabled");ui.feature("glow.flash")
            slider("Maximum distance (m)","glow.range","distance",1,300)
        end)
        ui.next_column()
        ui.group("Targets",function()
            ui.feature("glow.survivors");ui.feature("glow.specials")
            ui.feature("glow.common");ui.feature("glow.items")
        end)
    end)
end)
-- VFX keeps the existing world/chams IDs so profiles, scripts and shortcuts survive.
local vfx=ui.tab("vfx","VFX",{section="Visuals",icon=0xe231})
local previewMotion=true
local function motionToggle()
    local changed,value=ui.toggle("Animate preview",previewMotion)
    if changed then previewMotion=value end
end
-- Keep a single library beside an independently scrollable inspector.
local function vfxSplit(library,inspector)
    local width,height=imgui.available()
    local gap=14
    if width<430 then
        library()
        imgui.spacing(12)
        inspector()
        return
    end
    local side=math.max(188,math.min(246,width*.37))
    local panelHeight=math.max(80,height-4)
    imgui.child("vfx-library",width-side-gap,panelHeight,library)
    imgui.same_line(gap)
    imgui.child("vfx-inspector",side,panelHeight,function()
        inspector()
        imgui.spacing(12)
    end)
end
local function gallery(kind,names,first,current,onSelect,last)
    local width,height=imgui.available()
    local gap=8
    local count=width>=270 and 3 or width>=156 and 2 or 1
    local w=math.max(32,(width-gap*(count-1))/count)
    local rows=math.ceil(((last or #names)-first+1)/count)
    local h=math.max(kind=="material" and 50 or 58,math.min(w*.58+23,(height-10-gap*(rows-1))/rows))
    for i=first,last or #names do
        local column=(i-first)%count
        if column~=0 then imgui.same_line(gap)
        elseif i~=first then imgui.spacing(4) end
        if l4d.vfx_card(kind,i-1,current==i-1,w,h,false,"",ui.tr(names[i])) then onSelect(i-1) end
        imgui.tooltip(names[i])
    end
end
ui.subtab(vfx,"vfx_presets","Maps & looks",function() l4d.vfx_studio("looks") end)
ui.subtab(vfx,"vfx_sky","Sky",function() l4d.vfx_studio("sky") end)
ui.subtab(vfx,"vfx_lighting","Lighting",function() l4d.vfx_studio("lighting") end)
local vfxLayer=1
local materialLibrary=1
local libraryNotice={}
local initialMaterials=l4d.user_materials()
if #initialMaterials>0 then materialLibrary=2 end
for i,id in ipairs(chamsIds) do
    for _,pass in ipairs({i==1 and "chams.visible" or id..".custom",i==1 and "chams.hidden" or id..".hidden",id..".overlay"}) do
        ui.feature_visible(pass..".user_material",false)
    end
end
local function selectedPass()
    local selected=l4d.setting("chams.selector","style")+1
    local id=chamsIds[selected]
    return ({selected==1 and "chams.visible" or id..".custom",selected==1 and "chams.hidden" or id..".hidden",id..".overlay"})[vfxLayer]
end
ui.subtab(vfx,"vfx_materials","Materials",function()
    vfxSplit(function()
        local pass=selectedPass()
        local changed,value=ui.combo("Library",materialLibrary,{"Built-in materials","My materials"})
        if changed then materialLibrary=value end
        imgui.spacing(8)
        if materialLibrary==1 then
            gallery("material",materials,13,l4d.user_material(pass)==0 and l4d.setting(pass,"style") or -1,function(style)
                l4d.setting(pass,"style",style);l4d.user_material(pass,0)
            end)
        else
            local entries,folder,errors=l4d.user_materials()
            for _,action in ipairs({{"Open folder","open"},{"Refresh","refresh"},{"Add example","example"}}) do
                if ui.button(action[1]) then entries,folder,libraryNotice=l4d.user_materials(action[2]) end
                if action[2]~="example" then imgui.same_line() end
            end
            imgui.spacing(6)
            imgui.text("name.vmt + name.vtf")
            imgui.text("Preview: matching name.png or name.gif")
            if #entries==0 then imgui.text("Add your files, then press Refresh.") end
            local available=imgui.available()
            local columns=available>=250 and 3 or 2
            local width=math.max(32,(available-(columns-1)*10)/columns)
            local selected=l4d.user_material(pass)
            for i,item in ipairs(entries) do
                if l4d.vfx_card("user",item.id,selected==item.id,width,width*.64+28,previewMotion,"",item.name) then
                    l4d.user_material(pass,item.id)
                end
                if i%columns~=0 then imgui.same_line(10) end
            end
            imgui.spacing(8)
            for _,message in ipairs(errors) do imgui.text(message) end
            for _,message in ipairs(libraryNotice) do imgui.text(message) end
        end
    end,function()
        protectedGroup("Target and layer","chams.enabled",function()
            local selected=chamsTargetDropdown()
            toggle("Enable",chamsMaster(selected))
            toggle("Enable target",chamsIds[selected])
            if selected>=10 and selected<=17 then toggle("Special infected","chams.special") end
            local changed,value=ui.combo("Layer",vfxLayer,{"Visible","Invisible","Overlay"})
            if changed then vfxLayer=value end
        end)
        local pass=selectedPass()
        protectedGroup("Selected material","chams.enabled",function()
            local style=l4d.setting(pass,"style")
            local userId=l4d.user_material(pass)
            local selectedUser=nil
            for _,item in ipairs(l4d.user_materials()) do if item.id==userId then selectedUser=item end end
            if selectedUser or (userId==0 and style>=12) then
                local width=imgui.available()
                width=math.max(32,width)
                l4d.vfx_card(selectedUser and "user" or "material",selectedUser and userId or style,false,width,math.min(122,width*.57),previewMotion,pass)
                if selectedUser then imgui.text(selectedUser.name) end
                motionToggle()
            elseif userId~=0 then
                imgui.text("Custom material missing. Using built-in fallback.")
            end
            if userId~=0 and ui.button("Use built-in material") then l4d.user_material(pass,0) end
            ui.feature(pass)
            choice(userId~=0 and "Built-in fallback##vfx" or "Material##vfx",pass,"style",materials,true)
        end)
        protectedGroup("Layer animation","chams.enabled",function()
            local animation=pass..".animation"
            ui.feature(animation)
            choice("Animation##vfx",animation,"style",{"Static","Color wave","Pulse opacity","Rainbow colors","Shimmer","Ember flicker","Color surge","Color steps"})
            slider("Speed (Hz)",animation.."_speed","distance",.05,3)
            slider("Strength",animation.."_amount","distance",0,1)
            ui.keybind(animation)
        end)
        protectedGroup("Shared effects","chams.enabled",function()
            ui.feature("chams.pulse");ui.feature("chams.rainbow");ui.feature("chams.animation")
            slider("Shared speed (Hz)","chams.animation_speed","distance",.05,3)
            slider("Shared strength","chams.animation_amount","distance",0,1)
            ui.feature("chams.copy_pass");ui.feature("chams.swap_passes")
        end)
    end)
end)

ui.subtab(misc,"view","View",function()
    columns(function()
        ui.group("Camera",function()
            ui.feature("view.camera_fov")
            slider("FOV (degrees)","view.camera_fov","distance",60,140)
            ui.feature("view.keep_zoom")
        end)
        ui.group("Viewmodel",function()
            ui.feature("view.model_fov")
            slider("Model FOV (degrees)","view.model_fov","distance",40,140)
        end)
        l4d.protected_control("view.camera_fov",function()
        if ui.button("Reset view") then
            features.set("view.camera_fov",false);features.set("view.model_fov",false);features.set("view.offsets",false)
            features.set("view.keep_zoom",true);features.set("view.thirdperson",false)
            l4d.setting("view.thirdperson_distance","distance",120)
            l4d.setting("view.thirdperson_side","distance",20);l4d.setting("view.thirdperson_height","distance",5)
            l4d.setting("view.camera_fov","distance",90);l4d.setting("view.model_fov","distance",68)
            for _,id in ipairs({"view.offset_x","view.offset_y","view.offset_z"}) do l4d.setting(id,"distance",0) end
        end
        end)
        ui.next_column()
        ui.group("Third person",function()
            ui.feature("view.thirdperson")
            slider("Camera distance","view.thirdperson_distance","distance",40,200)
            slider("Shoulder - left / right","view.thirdperson_side","distance",-40,40)
            slider("Camera - down / up","view.thirdperson_height","distance",-30,30)
            ui.feature("view.swap_shoulder");ui.feature("view.center_camera")
        end)
        ui.next_column()
        ui.group("Model position",function()
            ui.feature("view.offsets")
            slider("X - left / right","view.offset_x","distance",-20,20)
            slider("Y - back / forward","view.offset_y","distance",-20,20)
            slider("Z - down / up","view.offset_z","distance",-20,20)
            imgui.text("Offsets follow the camera. Positive values move right, forward and up.")
        end)
    end)
end)
local debug=ui.tab("debug","Debug",{section="Misc",icon=0xe20c,hidden=true})
ui.subtab(debug,"session","Session",function()
    columns(function()
        ui.group("Engine",function()
            imgui.text(l4d.status())
            local speed,entities,properties=l4d.metrics()
            imgui.text(string.format(ui.tr("Entities: %d | Receive properties: %d"),entities,properties))
            ui.feature("debug.telemetry")
        end)
        ui.next_column()
        ui.group("Tool lifecycle",function()
            ui.feature("debug.block_input")
            ui.feature("debug.stop")
            imgui.text("Stop restores the game effects. Assign an optional shortcut in Hotkeys.")
        end)
    end)
end)

ui.subtab("settings", "performance", "Performance", function()
    ui.group("Model previews", function()
        ui.feature("preview.enabled")
    end)
end)
