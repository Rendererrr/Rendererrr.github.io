# Scooby — Setup & Troubleshooting Guide

## Account

Login:
https://scoobymenu.cc/portal/#login

Register:
https://scoobymenu.cc/portal/#register

Website:
https://scoobymenu.cc/

Guides:
https://scoobymenu.cc/guides

=======================================

## Before You Start

### 1. Install Visual C++ Runtimes

Install the Visual C++ Redistributable Runtime package to help prevent crashes:

https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/

Restart your PC after installation.

### 2. Update Your Graphics Drivers

Make sure your GPU drivers are updated to the latest compatible version before launching.

=======================================

## Troubleshooting

If you're experiencing crashes or other issues, try the following:

1. Perform a fresh installation
   - Delete the existing Scooby folder:
     C:\scooby
   - Reinstall Scooby afterward.

2. Check your antivirus
   - Make sure your antivirus isn't incorrectly quarantining or blocking required Scooby files.
   - Review your antivirus protection history/quarantine and add an appropriate exception if you trust the software.

3. Check Windows permissions
   - Verify that your Windows account has the necessary user/administrator permissions.

4. Try a new Windows user account
   - If permission or profile-related problems continue, create a new Windows user and test again.

Video Guide:
https://youtu.be/hZGIpUtk5ug?si=HCVIOvCfLEKLc8UL&t=32

=======================================

## GTA 5 — Enhanced & Legacy

Make sure to inject from the Main Menu / Loading Screen.

### Free & Premium Users

Follow the provided guide regarding BattlEye configuration:

https://youtu.be/rp08KxmkHy0

### Premium Plus Users

Premium Plus supports the documented injection flow with BattlEye enabled or disabled.

=======================================

## Still Having Problems?

Before requesting support, confirm that you have:

- Installed the required Visual C++ runtimes
- Restarted your PC
- Updated your graphics drivers
- Performed a fresh Scooby installation
- Checked antivirus quarantine/blocking
- Checked Windows user and administrator permissions
- Followed the appropriate GTA 5 setup instructions
