Silkroad All theme pack

Extract the Silkroad folder into C:/scooby/GTA5/Themes/ListUI or C:/scooby/RDR2/Themes/ListUI. Both Silkroad styles share these assets.
Select themes from Silkroad Appearance > Themes. Existing custom files are preserved by the in-game downloader. PNG artwork only; no translations or language fonts.
