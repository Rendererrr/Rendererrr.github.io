X-Force original themes: eight palettes and two original generated headers.
Apply Color Presets to retain artwork, layout and font choices. Full themes also select a header.
Portable .ui presets load through the standard Themes browser.
